$(document).ready(function () {

    /* min max price range slide */

    $("#slider-range").slider({
        range: true,
        orientation: "horizontal",
        min: 0,
        max: 10000,
        values: [0, 10000],
        step: 100,

        slide: function (event, ui) {
            if (ui.values[0] == ui.values[1]) {
                return false;
            }

            $("#min_price").val(ui.values[0]);
            $("#max_price").val(ui.values[1]);
        }
    });

    $("#min_price").val($("#slider-range").slider("values", 0));
    $("#max_price").val($("#slider-range").slider("values", 1));

    /* dropdown btn */

    var submenudrop0 = document.querySelector(".listiningbtn0");
    var listiningsub0 = document.querySelector(".submenu0");

    submenudrop0.addEventListener('click', function () {
        listiningsub0.classList.toggle("subshow");
    });

    var submenudrop1 = document.querySelector(".listiningbtm1");
    var listiningsub1 = document.querySelector(".submenu1");

    submenudrop1.addEventListener('click', function () {
        listiningsub1.classList.toggle("subshow");
    });

    var submenudrop2 = document.querySelector(".listiningbtm2");
    var listiningsub2 = document.querySelector(".submenu2");

    submenudrop2.addEventListener('click', function () {
        listiningsub2.classList.toggle("subshow");
    });

    /* hide dropdown click on body */

    window.onclick = function (event) {
        var submenu0 = document.querySelector(".submenu0");

        if (!event.target.matches('.pricbtn, .submenu0')) {
            submenu0.classList.remove('subshow');
        }

        var submenu1 = document.querySelector(".submenu1");

        if (!event.target.matches('.listiningbtm1, .submenu1')) {
            submenu1.classList.remove('subshow');
        }
        var submenu2 = document.querySelector(".submenu2");

        if (!event.target.matches('.listiningbtm2, .submenu2')) {
            submenu2.classList.remove('subshow');
        }
    }

    /* start sidebar slide 
    
    var opennav = document.querySelector('.openbtn');
    var closenav = document.querySelector('.closebtn');
    
    var sidebar = document.querySelector('.sidebar');
    
    opennav.addEventListener('click',function(){
        sidebar.style.width="250px";
    });
    
    closenav.addEventListener('click',function(){
        sidebar.style.width="0";
    });

*/

    /* chatbot toggle */
    
    $(".chat-bot-icon").click(function (e) {
            $(this).children('img').toggleClass('hide');
            $(this).children('svg').toggleClass('animate');
            $('.chat-screen').toggleClass('show-chat');
        });
    
    /* item slider */
    
     /* popular news slider */
    $('.itemslider').slick({
         autoplay: true,
        infinite: true,
        nav: false,
        dost: false,
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        responsive: [
            {
                breakpoint: 1198,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 3,
                    infinite: true,
                    nav: false,
                    dots: false
                }
    },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 2,
                    nav: false,
                    dots: false
                }
    },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    nav: false,
                    dots: false
                }
    }

  ]
    });
    
});
